<!DOCTYPE html>
<html>
<head>
<title>terms-and-conditions</title>
</head>
<body>
  <div class="container-fluid">
<p>GENERAL TERMS <br>

All Information Displayed, Transmitted Or Carried On GENICS TECHSOL PVT.LTD. Is Protected By Copyright And Other Intellectual Property Laws.
This Site Is  Updated And Maintained Independently By GENICS TECHSOL PVT.LTD. The Content Is Owned By GENICS TECHSOL PVT.LTD. You May Not Modify, Publish, Transmit, Transfer, Sell, Reproduce, Create Derivative Work From, Distribute, Repost, Perform, Display Or In Any Way Commercially Exploit Any Of The Content.
GENICS TECHSOL PVT.LTD. Disclaims All Warranties Or Conditions, Whether Expressed Or Implied, (Including Without Limitation Implied, Warranties Or Conditions Of Information And Context). We Consider Ourselves And Intend To Be Subject To The Jurisdiction Only Of The Courts Of INDORE, India.
GENICS TECHSOL PVT.LTD. Reserves The Right, In Its Sole Discretion, To Suspend Or Cancel The Service At Any Time If A Computer Virus, Bug, Or Other Technical Problem Corrupts The Security, Or Proper Administration Of The Service.
GENICS TECHSOL PVT.LTD. Values The Privacy Of Information Pertaining To Its Associates. We Do Not Use Or Disclose Information About Your Individual Visits To Our Website Or Any Information That You May Give Us, Such As Your Name, Address, Email Address Or Telephone Number, To Any Outside Sources.
GENICS TECHSOL PVT.LTD. Reserves The Right To Refuse Service To Anyone At Any Time.
GENICS TECHSOL PVT.LTD. Will Not Use Information About You Without Your Permission And Will Provide The Means For You To Manage And Control The Information That You Have Provided. We Will Enable You To Communicate Your Privacy Concerns To Us And That We Will Respond To Them Appropriately.
GENICS TECHSOL PVT.LTD. Does Not Disclose Any Personal Information To Advertisers And For Other Marketing And Promotional Purposes That Could Be Used To Personally Identify You, Such As Your Password, Credit Card Number And Bank Account Number.
GENICS TECHSOL PVT.LTD. Will Not Accept Any Cash Payments Above 50,000/-.

<br>


Disclaimer Policy  <br>

GENICS TECHSOL PVT.LTD. And Their Respective Publishers, Authors, Agents And Employees Have Done Their Best To Ensure The Accuracy And Currency Of All The Information On This Website Contributed By Them; However, They Accept No Responsibility For Any Loss, Injury, Or Damages Sustained By Anyone As A Result Of Information Or Advice Contained On The Site Nor For The Results Of Any Travel Arrangement Originating From This Site. The Use Of Information On Or Derived From This Site And Any Arrangement For Travel With Person's Contacted Through The Site Is Made At The User's Own Risk. We Encourage You To Verify Any Critical Information With The Relevant Authorities Before You Travel. This Includes Information On Visa Requirements, Health And Safety, Customs, And Transportation. GENICS TECHSOL PVT.LTD. And Their Respective Publishers, Authors, Agents And Employees Make No Representations About The Suitability Of The Information Contained In The Documents And Related Graphics Published On This Website For Any Purpose. All Such Documents And Related Graphics Are Provided ''As Is'' Without Warranty Of Any Kind, Statutory Or Otherwise. GENICS TECHSOL PVT.LTD. And Their Respective Publishers, Authors, Agents And Employees Disclaim All Warranties And Conditions With Regard To This Internet Site And The Information Contained Therein, Including, Without Limitation, All Implied Warranties And Conditions Of Merchantability, Fitness For A Particular Purpose, Title, And Non-Infringement. In No Event Shall GENICS TECHSOL PVT.LTD. And Their Respective Publishers, Authors, Agents And Employees, Be Liable For Any Special, Indirect, Or Consequential Damages Or Any Damages Whatsoever Whether In An Action Of Contract, Negligence, Or Other Tortuous Action, Arising Out Of Or In Connection With The Use Or Performance Of This Internet Site Or Of The Information And Documents Contained Therein, Provision Of Or Failure To Provide Services, Or Any Other Information Directly Or Indirectly Available From This Website. The Documents And Related Graphics Published On This Website Could Include Technical Inaccuracies Or Typographical Errors. Changes Are Periodically Added To The Information Herein. GENICS TECHSOL PVT.LTD.  May Make Improvements And/Or Changes In The Product(S) Described Herein At Any Time. The Linked Sites Are Not Under The Control Of GENICS TECHSOL PVT.LTD. And Their Respective Employees Are Not Responsible For The Contents Of Any Linked Site Or Any Link Contained In A Linked Site. GENICS TECHSOL PVT.LTD. Is Providing These External Links To You Only As A Convenience, And The Inclusion Of Any Link Does Not Imply Endorsement By    GENICS TECHSOL PVT.LTD. Of The Site. All Views Expressed By Individuals On This Site Are Their Personal Opinions And Are Not Necessarily Those Of Or Endorsed By        GENICS TECHSOL PVT.LTD.</p>
</div>


</body>
</html>


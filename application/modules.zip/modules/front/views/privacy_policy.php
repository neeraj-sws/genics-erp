<!DOCTYPE html>
<html>
<head>
<title>privacy-policy</title>
</head>
<body>

<div class="container-fluid">
<p>PRIVACY POLICY <br>
 

 We Are Committed To Protecting Your Privacy. We Will Only Use The Information That We Collect About You Lawfully.<br>
 We Collect Information About You For 2 Reasons: Firstly, To Process Your Order And Second, To Provide You With The Best Possible Service.<br>
 We Will Give You The Chance To Refuse Any Marketing Email From Us.<br>
 The Type Of Information We Will Collect About You Includes:<br>
  Your Name , Address<br>
  Phone Number & Email Address.<br>
 The Information We Hold Will Be Accurate And Up To Date. You Can Check The Information That We Hold About You By Emailing Us. If You Find Any Inaccuracies We Will Delete Or Correct It Promptly.<br>
 The Personal Information Which We Hold Will Be Held Securely In Accordance With Our Internal Security Policy And The Law.<br>
 We May Use Technology To Track The Patterns Of Behaviour Of Visitors To Our Site. This Can Include Using A "Cookie" Which Would Be Stored On Your Browser. You Can Usually Modify Your Browser To Prevent This Happening. The Information Collected In This Way Can Be Used To Identify You Unless You Modify Your Browser Settings.<br>
 If You Have Any Questions/Comments About Privacy, You Should Contact Us.</p>
</div>
</body>
</html>

